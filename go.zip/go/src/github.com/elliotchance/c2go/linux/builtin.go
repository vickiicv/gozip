// Package linux contains low-level functions for the Linux operating system.
package linux
