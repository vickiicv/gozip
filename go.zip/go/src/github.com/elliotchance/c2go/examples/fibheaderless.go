/*
	Package main - transpiled by c2go version: v0.26.0 Erbium 2020-03-17

	If you have found any issues, please raise an issue at:
	https://github.com/elliotchance/c2go/
*/

// Warning (CallExpr):  C:\Users\windows 8\go\src\github.com\elliotchance\c2go\examples\fibheaderless.c:5 : Cannot casting {int -> ...}. err = Cannot resolve type '...' : I couldn't find an appropriate Go type for the C type '...'.
// Warning (CallExpr):  C:\Users\windows 8\go\src\github.com\elliotchance\c2go\examples\fibheaderless.c:17 : Cannot casting {int -> ...}. err = Cannot resolve type '...' : I couldn't find an appropriate Go type for the C type '...'.

package main

// main - transpiled function from  C:\Users\windows 8\go\src\github.com\elliotchance\c2go\examples\fibheaderless.c:1
// Warning (CallExpr):  C:\Users\windows 8\go\src\github.com\elliotchance\c2go\examples\fibheaderless.c:5 : Cannot casting {int -> ...}. err = Cannot resolve type '...' : I couldn't find an appropriate Go type for the C type '...'.
// Warning (CallExpr):  C:\Users\windows 8\go\src\github.com\elliotchance\c2go\examples\fibheaderless.c:17 : Cannot casting {int -> ...}. err = Cannot resolve type '...' : I couldn't find an appropriate Go type for the C type '...'.
func main() {
	var n int32 = int32(5)
	var first int32 = int32(0)
	var second int32 = int32(1)
	var next int32
	var c int32
	printf((&[]byte("First %d terms of Fibonacci series are :-\n\x00")[0]), nil)
	for c = int32(0); c < n; c++ {
		if c <= int32(1) {
			next = c
		} else {
			next = first + second
			first = second
			second = next
		}
		printf((&[]byte("%d\n\x00")[0]), nil)
	}
	return
}
func init() {
}
