#include <stdio.h>

// Checking case with header on another folder then main function
void print(){
	// tests that functions can be declared in the header.
	printf("42");
}
