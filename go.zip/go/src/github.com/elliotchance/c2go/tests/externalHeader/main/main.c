#include "head.h"

// Checking case with header on another folder then main function
int main(){
	print();
	return 0;
}
