#include <stdlib.h>
#include "tests.h"

int main()
{
    plan(0);

    exit(123);

    // done_testing() is not needed because this is unreachable.
}
