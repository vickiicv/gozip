void operators_equals()
{
	int a,b,c,d;
	a=b=c=d=42;
}
