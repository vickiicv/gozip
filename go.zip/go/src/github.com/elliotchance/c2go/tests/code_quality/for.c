void f1()
{
	int i;
	for ( i = 0 ; i < 10 ; i++){;}
}

void f2()
{
	int i;
	for ( i = 10 ; i > 0 ; i--){;}
}

void f3()
{
	for( int i = 0; i< 10 ;i++){;}
}
