/*
	Package main - transpiled by c2go version: v0.23.0 Berkelium 2018-04-27

	If you have found any issues, please raise an issue at:
	https://github.com/elliotchance/c2go/
*/

package code_quality

// operators_equals - transpiled function from  tests/code_quality/operators.c:1
func operators_equals() {
	var a int32
	var b int32
	var c int32
	var d int32
	d = int32(42)
	c = d
	b = c
	a = b
}
func init() {
}
