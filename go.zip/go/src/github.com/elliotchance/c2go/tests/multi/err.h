#include <stdio.h>

void ERROR_FUNC(){
	printf("ERROR!");
}
