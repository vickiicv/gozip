#include <stdio.h>
#include "header.h"

void say_three() {
    printf("3");
}
