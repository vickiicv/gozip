package noarch

type VaList struct {
	Pos  int
	Args []interface{}
}
